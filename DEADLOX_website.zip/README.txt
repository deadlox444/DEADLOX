DEADLOX WEBSITE
Open index.html in a browser.

CUSTOMIZE:
1. Replace the # social links in index.html with your real Instagram/TikTok/Facebook/YouTube URLs.
2. Replace YOUR_EMAIL@example.com in script.js with your business email.
3. Replace the sample products/prices with your actual stock.
4. Product images can replace the .product-img blocks with <img> elements.
5. For real checkout/payment, connect a payment/store platform such as Shopify, WooCommerce, Stripe Checkout, or another provider.

This is a responsive static storefront front-end.
