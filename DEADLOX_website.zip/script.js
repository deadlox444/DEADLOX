const menu=document.querySelector('.menu'); const nav=document.querySelector('.nav nav');
menu.addEventListener('click',()=>nav.classList.toggle('open'));
function toast(msg){const t=document.getElementById('toast');t.textContent=msg;t.style.display='block';setTimeout(()=>t.style.display='none',2500)}
function order(item){toast(item+' selected — connect your order system to accept payments.')}
function social(e,name){e.preventDefault();toast(name+' link is ready — replace the # link in index.html with your profile URL.')}
function sendMail(e){e.preventDefault();const n=document.getElementById('name').value;const em=document.getElementById('email').value;const m=document.getElementById('message').value;window.location.href='mailto:YOUR_EMAIL@example.com?subject=DEADLOX%20Website%20Contact%20from%20'+encodeURIComponent(n)+'&body='+encodeURIComponent(m+'\\n\\nReply to: '+em);toast('Opening your email app…');}